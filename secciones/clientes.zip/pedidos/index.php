<?php
include("../../bd.php");

// Eliminar pedido por order_id
if(isset($_GET['txtID'])){
    $txtID = (isset($_GET['txtID']))?$_GET['txtID']:"";

    $sentencia = $conexion->prepare("DELETE FROM orders WHERE order_id = :id");
    $sentencia->bindParam(":id",$txtID);
    $sentencia->execute();

    $mensaje="Registro eliminado";
    header("Location:index.php?mensaje=".$mensaje);
    exit;
}

// Consulta para pedidos (columnas: order_id, customer_id, order_date, user_id, estado, total_amount)
$sentencia = $conexion->prepare("SELECT * FROM orders");
$sentencia->execute();
$lista_pedidos = $sentencia->fetchAll(PDO::FETCH_ASSOC);
?>
<?php include("../../templates/header.php") ?>
<br>
<div class="card">
    <div class="card-header">
        <a class="btn btn-outline-primary" href="crear.php" role="button">Nuevo</a>
    </div>
    <div class="card-body">
        <?php if(isset($_GET['mensaje'])) { ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo ($_GET['mensaje']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php } ?>
        <div class="table-responsive-sm">
            <table class="table table-bordered table-striped ">
                <thead class="table-primary">
                    <tr>
                        <th scope="col">Pedido ID</th>
                        <th scope="col">Cliente ID</th>
                        <th scope="col">Fecha de pedido</th>
                        <th scope="col">Usuario ID</th>
                        <th scope="col">Estado</th>
                        <th scope="col">Total</th>
                        <th scope="col">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($lista_pedidos as $registro) {
                        $id = $registro['order_id'] ?? $registro['customer_id'] ?? '';
                        ?>
                    <tr>
                        <td scope="row"><?php echo ($id); ?></td>
                        <td><?php echo ($registro['customer_id']); ?></td>
                        <td><?php echo ($registro['order_date']); ?></td>
                        <td><?php echo ($registro['user_id']); ?></td>
                        <td><?php echo ($registro['estado']); ?></td>
                        <td><?php echo ($registro['total_amount'] ); ?></td>
                        <td>
                            <a class="btn btn-outline-primary" href="editar.php?txtID=<?php echo $registro['order_id']; ?>" role="button">Editar</a>
                            <a class="btn btn-outline-danger" href="index.php?txtID=<?php echo $registro['order_id']; ?>" onclick="return confirm('¿Eliminar este pedido?');" role="button">Eliminar</a>
                        </td>
                    </tr>
                    <?php } ?>
                    <?php if(empty($lista_pedidos)) { ?>
                    <tr>
                        <td colspan="7" class="text-center">No hay pedidos</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        
    </div>
    <div class="card-footer text-muted">Footer</div>
</div>

<?php include("../../templates/footer.php") ?>
