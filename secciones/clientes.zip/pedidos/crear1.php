<?php include("../../bd.php");
//traer los datos de clientes y productos para las listas desplegables
$customer=$conexion->prepare("SELECT customer_id, CONCAT(first_name,' ',last_name) AS name 
FROM customers ORDER BY name ")->fetchAll(PDO::FETCH_ASSOC);
$product=$conexion->query("SELECT product_id, product_name, price FROM products 
ORDER BY product_name ")->fetchAll(PDO::FETCH_ASSOC);
// creamos un arreglo asociativo para JS (product_id => list_price)
$productPrices = [];
foreach ($product as $prod) {
    $productPrices[$prod['product_id']] = $prod['price'];
}
//PROGRAMAMOS UN BLOQUE DE TRANSACCION
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    try {
        $conexion->beginTransaction();
        // Insertar en la tabla orders
        $smtOrder = $conexion->prepare("INSERT INTO orders (customer_id, order_date, user_id, estado, total_amount) 
        VALUES (?,?,?,?,?)");
        $smtOrder->execute([
            $_POST['customer_id'],
            $_POST['order_date'],
            $_POST['user_id'],
            $_POST['estado'],
            $_POST['total_amount']
        ]);

        $orderId = $conexion->lastInsertId();
        // Insertar en la tabla order_items
        $smtItem = $conexion->prepare("INSERT INTO order_items (order_id, product_id, quantity, price, discount) 
        VALUES (?,?,?,?,?)");
        foreach ($_POST['items'] as $item) {
            $smtItem->execute([
                $orderId,
                $item['product_id'],
                $item['quantity'],
                $item['price'],
                $item['discount']
            ]);
        }
        $conexion->commit();
        $mensaje = "Pedido creado exitosamente";
    }
    catch (Exception $e) {
        $conexion->rollBack();
        $mensaje="Se produjo un error al crear el pedido: " . $e->getMessage();
    }
}
?>
<?php include("../../templates/header.php") ?>
<div class="card">
    <div class="card-header">
        <h3>Registrar nuevo pedido</h3>
        <a class="btn btn-outline-primary" href="index.php" role="button">
            <i class="bi bi-skip-backward-btn me-2"></i>Atr&aacute;s</a>
    </div>
    <div class="card-body">
        <div>
            <?php if(!empty ($mensaje)): ?>
                <p><strong><?= htmlspecialchars($mensaje) ?></strong></p>
            <?php endif; ?>
        </div>