<?php include("../../bd.php");

if($_POST){
    $order_id = isset($_POST["order_id"]) ? $_POST["order_id"] : "";
    $product_id = isset($_POST["product_id"]) ? $_POST["product_id"] : "";
    $quantity = isset($_POST["quantity"]) ? $_POST["quantity"] : 0;
    $price = isset($_POST["price"]) ? $_POST["price"] : 0;
    $discount = isset($_POST["discount"]) ? $_POST["discount"] : 0;

    $sentencia = $conexion->prepare("INSERT INTO order_items (order_id, product_id, quantity, price, discount)
        VALUES (:order_id, :product_id, :quantity, :price, :discount)");
    $sentencia->bindParam(":order_id", $order_id);
    $sentencia->bindParam(":product_id", $product_id);
    $sentencia->bindParam(":quantity", $quantity);
    $sentencia->bindParam(":price", $price);
    $sentencia->bindParam(":discount", $discount);
    $sentencia->execute();

    $mensaje = "Artículo de pedido agregado";
    header("Location:index.php?mensaje=".$mensaje);
    exit;
}
?>
<?php include("../../templates/header.php") ?>

<div class="container mt-5 mb-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h2 class="mb-4"><i class="bi bi-plus-circle"></i> Nuevo artículo de pedido</h2>

            <div class="card">
                <div class="card-body">
                    <form action="" method="post">
                        <div class="mb-3">
                            <label for="order_id" class="form-label">ID Pedido</label>
                            <input type="number" class="form-control" name="order_id" id="order_id" required>
                        </div>

                        <div class="mb-3">
                            <label for="product_id" class="form-label">ID Producto</label>
                            <input type="number" class="form-control" name="product_id" id="product_id" required>
                        </div>

                        <div class="mb-3">
                            <label for="quantity" class="form-label">Cantidad</label>
                            <input type="number" class="form-control" name="quantity" id="quantity" value="1" min="0" step="1" required>
                        </div>

                        <div class="mb-3">
                            <label for="price" class="form-label">Precio</label>
                            <input type="number" class="form-control" name="price" id="price" value="0.00" min="0" step="0.01" required>
                        </div>

                        <div class="mb-3">
                            <label for="discount" class="form-label">Descuento</label>
                            <input type="number" class="form-control" name="discount" id="discount" value="0.00" min="0" step="0.01">
                        </div>

                        <div class="d-flex justify-content-end gap-2">
                            <button type="submit" class="btn btn-success">Guardar</button>    
                            <a href="index.php" class="btn btn-primary">Cancelar</a>                            
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

<?php include("../../templates/footer.php") ?>