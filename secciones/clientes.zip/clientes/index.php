<?php
include("../../bd.php");
//Envio de parametros en la URL o en el metodo GET
if(isset($_GET['txtID'])){
    $txtID = (isset($_GET['txtID']))?$_GET['txtID']:"";
    //buscar el archivo de cliente
    $sentencia=$conexion->prepare("SELECT imagen FROM customers WHERE customers_id=:id");
    $sentencia->bindParam(":id",$txtID);
    $sentencia->execute();
    $registro=$sentencia->fetch(PDO::FETCH_LAZY);
    $registro_recuperado = $registro;
    
    if(isset($registro_recuperado["imagen"]) && $registro_recuperado["imagen"]!=""){
        if(file_exists("./imagen/".$registro_recuperado["imagen"])){
            unlink("./imagen/".$registro_recuperado["imagen"]);
        }
    }
    
    $sentencia=$conexion->prepare("DELETE FROM customers WHERE customers_id=:id");
    $sentencia->bindParam(":id",$txtID);
    $sentencia->execute();
    $mensaje="Registro eliminado";
    header("Location:index.php?mensaje=".$mensaje);
    exit;
}

//Consulta para clientes para mostrar como un registro
$sentencia=$conexion->prepare("SELECT * FROM customers");
$sentencia->execute();
$lista_clientes = $sentencia->fetchAll(PDO::FETCH_ASSOC);
?>
<?php include("../../templates/header.php") ?>



<br>
<?php if(isset($_GET['mensaje'])) { ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle"></i>
        <?php echo htmlspecialchars($_GET['mensaje']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php } ?>

<div class="card">
    <div class="card-header">
        <a class="btn btn-outline-primary" href="crear.php" role="button">
            <i class="bi bi-plus-circle"></i> Nuevo
        </a>
    </div>
    <div class="card-body">
        <div class="table-responsive-sm">
            <table class="table table-bordered table-striped tabla-clientes">
                <thead class="table-primary">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Apellido</th>
                        <th scope="col">Imagen</th>
                        <th scope="col">Teléfono</th>
                        <th scope="col">Email</th>
                        <th scope="col">Dirección</th>
                        <th scope="col">Ciudad</th>
                        <th scope="col">Estado</th>
                        <th scope="col">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($lista_clientes as $registro) { 
                        $id = $registro['customers_id'] ?? $registro['customer_id'] ?? '';
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($id); ?></td>
                        <td><?php echo htmlspecialchars($registro['first_name'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($registro['last_name'] ?? ''); ?></td>
                        <td><img width="50" src="./imagen/<?php echo ($registro['imagen']); ?>"
                            class="img-fluid rounded" alt="Foto del cliente"/>
                        </td>
                        <td><?php echo htmlspecialchars($registro['phone'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($registro['email'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($registro['street'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($registro['city'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($registro['state'] ?? ''); ?></td>
                        <td>
                            <a class="btn btn-outline-primary btn-sm" href="editar.php?txtID=<?php echo $id; ?>" role="button">
                                <i class="bi bi-pencil"></i> Editar
                            </a>
                            <a class="btn btn-outline-danger btn-sm" href="index.php?txtID=<?php echo $id; ?>" onclick="return confirm('¿Estás seguro?');" role="button">
                                <i class="bi bi-trash"></i> Eliminar
                            </a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="card-footer text-muted">Total de clientes: <?php echo count($lista_clientes); ?></div>
</div>

<?php include("../../templates/footer.php") ?>