<?php include("../../bd.php");

if(isset($_GET['txtID'])){
    $txtID = (isset($_GET['txtID']))?$_GET['txtID']:"";
    //buscar el archivo de producto
    $sentencia=$conexion->prepare("SELECT foto FROM products WHERE product_id=:id");
    $sentencia->bindParam(":id",$txtID);
    $sentencia->execute();
    $registro=$sentencia->fetch(PDO::FETCH_LAZY);
    $registro_recupeardo = $registro;
    
    if(isset($registro_recupearado["foto"]) && $registro_recupeardo["foto"]!=""){
        if(file_exists("./imagen/".$registro_recupeardo["foto"])){
            unlink("./imagen/".$registro_recupeardo["foto"]);
        }
    }
    
    $sentencia=$conexion->prepare("DELETE FROM products WHERE product_id=:id");
    $sentencia->bindParam(":id",$txtID);
    $sentencia->execute();
    $memsaje="Registro eliminado";
    header("Location:index.php?mensaje=".$memsaje);
}

$sentencia=$conexion->prepare("SELECT *,
(select category_name from categories where categories.category_id=products.category_id limit 1) as categoria
 FROM products");
$sentencia->execute();
$lista_productos = $sentencia->fetchAll(PDO::FETCH_ASSOC); 

?>
<?php include("../../templates/header.php") ?>
<br>
<div class="card">
    <div class="card-header">
        <a name="" id="" class="btn btn-outline-primary" href="crear.php" role="button">Nuevo</a>
    </div>
    <div class="card-body">
        <div class="table-responsive-sm">
            <table class="table table-bordered table-striped ">
                <thead class="table-primary">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Producto</th>
                        <th scope="col">Foto</th>
                        <th scope="col">Modelo año</th>
                        <th scope="col">Precio</th>
                        <th scope="col">Categoria</th>
                        <th scope="col">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php foreach($lista_productos as $registro) { ?>
                    <tr class="">
                        <td scope="row"><?php echo $registro['product_id']; ?></td>
                        <td><?php echo $registro['product_name']; ?></td>
                        <td><img width="50" src="./imagen/<?php echo $registro['foto']; ?>"
                            class="img-fluid rounded" alt="Foto del producto"/>
                        </td>
                        <td><?php echo $registro['model_year'] ?></td>
                        <td>
                            <span style="color: green; font-weight: bold; font-size: 1.1rem;">
                                $<?php echo number_format($registro['price'], 2); ?>
                            </span>
                        </td>
                        <td><?php echo $registro['category_id'] ?></td>
                        <td>
                            <a class="btn btn-outline-primary" href="editar.php?txtID=<?php echo $registro['product_id']; ?>" role="button">Editar</a>
                            <a class="btn btn-outline-danger" href="index.php?txtID=<?php echo $registro['product_id']; ?>" role="button">Eliminar</a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        
    </div>
    <div class="card-footer text-muted">Footer</div>
</div>


<?php include("../../templates/footer.php") ?>
