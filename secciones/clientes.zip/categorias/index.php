<?php include("../../bd.php");


if(isset($_GET['txtID'])){
    $txtID = (isset($_GET['txtID']))? $_GET['txtID'] : "";
 
    $sentencia = $conexion->prepare("SELECT * FROM categories WHERE category_id = :id");
    $sentencia->bindParam(":id", $txtID);
    $sentencia->execute();
    $registro = $sentencia->fetch(PDO::FETCH_LAZY);

 
    try {
        $sentencia = $conexion->prepare("DELETE FROM categories WHERE category_id = :id");
        $sentencia->bindParam(":id", $txtID);
        $sentencia->execute();
        $mensaje = "Registro eliminado";
        header("Location:index.php?mensaje=".urlencode($mensaje));
        exit;
    } catch(Exception $ex) {
    
        $mensaje = "Error al eliminar: " . $ex->getMessage();
        header("Location:index.php?mensaje=".urlencode($mensaje));
        exit;
    }
}

// Obtener lista de categorías ordenadas por id 
$sentencia = $conexion->prepare("SELECT * FROM categories ORDER BY category_id ASC");
$sentencia->execute();
$lista_categorias = $sentencia->fetchAll(PDO::FETCH_ASSOC);
?>
<?php include("../../templates/header.php") ?>

<style>
    .tabla-categorias {
        border: 3px solid #0d6efd;
    }
    .tabla-categorias th, .tabla-categorias td {
        border: 2px solid #0d6efd;
    }
</style>

<br>
<?php if(isset($_GET['mensaje'])) { ?>
    <div class="alert alert-info alert-dismissible fade show" role="alert">
        <?php echo htmlspecialchars($_GET['mensaje']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php } ?>

<div class="card">
    <div class="card-header">
        <a class="btn btn-outline-primary" href="crear.php" role="button">
            <i class="bi bi-plus-circle"></i> Nuevo
        </a>
    </div>
    <div class="card-body">
        <div class="table-responsive-sm">
            <table class="table tabla-categorias">
                <thead class="table-primary">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($lista_categorias) > 0) {
                        foreach($lista_categorias as $registro) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($registro['category_id']); ?></td>
                        <td><?php echo htmlspecialchars($registro['category_name']); ?></td>
                        <td>
                            <a class="btn btn-outline-primary btn-sm" href="editar.php?txtID=<?php echo $registro['category_id']; ?>" role="button">
                                <i class="bi bi-pencil"></i> Editar
                            </a>
                            <a class="btn btn-outline-danger btn-sm" href="index.php?txtID=<?php echo $registro['category_id']; ?>" onclick="return confirm('¿Estás seguro de eliminar esta categoría?');" role="button">
                                <i class="bi bi-trash"></i> Eliminar
                            </a>
                        </td>
                    </tr>
                    <?php } 
                    } else { ?>
                    <tr>
                        <td colspan="3" class="text-center text-muted py-4">
                            <i class="bi bi-inbox" style="font-size: 2rem;"></i>
                            <p class="mt-2">No hay categorías registradas</p>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="card-footer text-muted">Footer</div>
</div>

<?php include("../../templates/footer.php") ?>